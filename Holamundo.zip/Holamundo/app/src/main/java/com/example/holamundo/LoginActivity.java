package com.example.holamundo;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class LoginActivity extends AppCompatActivity {

    private EditText etNombre, etTelefono;
    private Button btnIngresar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        etNombre = findViewById(R.id.etNombre);
        etTelefono = findViewById(R.id.etTelefono);
        btnIngresar = findViewById(R.id.btnIngresar);

        btnIngresar.setOnClickListener(v -> {
            String nombre = etNombre.getText().toString().trim();
            String telefono = etTelefono.getText().toString().trim();

            if (nombre.isEmpty() || telefono.isEmpty()) {
                Toast.makeText(LoginActivity.this,
                        "Por favor, completa todos los campos",
                        Toast.LENGTH_SHORT).show();
            } else {
                Intent intent = new Intent(LoginActivity.this, InfoActivity.class);
                intent.putExtra("NOMBRE", nombre);
                intent.putExtra("TELEFONO", telefono);
                startActivity(intent);
            }
        });
    }
}