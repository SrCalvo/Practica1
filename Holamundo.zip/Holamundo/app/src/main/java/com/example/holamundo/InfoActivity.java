package com.example.holamundo;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class InfoActivity extends AppCompatActivity {

    private TextView tvNombre, tvTelefono;
    private Button btnRegresar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_info);

        tvNombre = findViewById(R.id.tvNombre);
        tvTelefono = findViewById(R.id.tvTelefono);
        btnRegresar = findViewById(R.id.btnRegresar);

        Intent intent = getIntent();
        String nombre = intent.getStringExtra("NOMBRE");
        String telefono = intent.getStringExtra("TELEFONO");

        tvNombre.setText("Nombre: " + nombre);
        tvTelefono.setText("Teléfono: " + telefono);

        btnRegresar.setOnClickListener(v -> {
            finish();
        });
    }
}